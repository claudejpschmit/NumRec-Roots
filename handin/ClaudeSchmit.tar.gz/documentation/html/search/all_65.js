var searchData=
[
  ['evaluate',['evaluate',['../classROOTFINDER_1_1Function.html#a2f13c8c1840054d0740d1deb9a6a3cb7',1,'ROOTFINDER::Function::evaluate()'],['../classROOTFINDER_1_1f1.html#af46273ec5e82a400bc5bc168e90d237c',1,'ROOTFINDER::f1::evaluate()'],['../classROOTFINDER_1_1f2.html#a16ec6c4b263cb87aee591c98bb03fecd',1,'ROOTFINDER::f2::evaluate()']]]
];
