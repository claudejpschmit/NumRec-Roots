var searchData=
[
  ['plot_5fover_5frange',['plot_over_range',['../classROOTFINDER_1_1Function.html#a29858efc6b1912d1975321fa7f3e9ec5',1,'ROOTFINDER::Function']]]
];
