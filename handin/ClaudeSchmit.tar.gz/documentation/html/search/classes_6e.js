var searchData=
[
  ['nrmethod',['NRMethod',['../classROOTFINDER_1_1NRMethod.html',1,'ROOTFINDER']]]
];
