var searchData=
[
  ['nrmethod',['NRMethod',['../classROOTFINDER_1_1NRMethod.html',1,'ROOTFINDER']]],
  ['nrmethod',['NRMethod',['../classROOTFINDER_1_1NRMethod.html#a98fe095ea0a37d384f53982ef81233bd',1,'ROOTFINDER::NRMethod']]]
];
