var searchData=
[
  ['_7efunction',['~Function',['../classROOTFINDER_1_1Function.html#ace9c2bbfe50901d5640933c977be9cc4',1,'ROOTFINDER::Function']]],
  ['_7erootfinder',['~Rootfinder',['../classROOTFINDER_1_1Rootfinder.html#aa945a1e658cb9e7f0843483993200346',1,'ROOTFINDER::Rootfinder']]]
];
