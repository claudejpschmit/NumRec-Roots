var searchData=
[
  ['get_5fstepcount',['get_stepcount',['../classROOTFINDER_1_1Rootfinder.html#ab9ebaa6eb5a8e828cc60d568b60f0535',1,'ROOTFINDER::Rootfinder']]]
];
