var searchData=
[
  ['find_5fin_5frange',['find_in_range',['../classROOTFINDER_1_1Rootfinder.html#a12e7c44a545409fba6bc6756f9242c34',1,'ROOTFINDER::Rootfinder::find_in_range()'],['../classROOTFINDER_1_1BisectionMethod.html#a6fc660ef7c9c32545e9ed164d7434605',1,'ROOTFINDER::BisectionMethod::find_in_range()'],['../classROOTFINDER_1_1NRMethod.html#a170a88b25167ea42ae12f6f27f6dc16b',1,'ROOTFINDER::NRMethod::find_in_range()']]],
  ['first_5fderivative',['first_derivative',['../classROOTFINDER_1_1Function.html#a6630779e9ce374d212e8ef7dd97943bc',1,'ROOTFINDER::Function::first_derivative()'],['../classROOTFINDER_1_1f1.html#a8b2e283e8bf948a46fa37b523a44c27d',1,'ROOTFINDER::f1::first_derivative()'],['../classROOTFINDER_1_1f2.html#a43311cc58f86d1b33874ed44b8973cc5',1,'ROOTFINDER::f2::first_derivative()']]]
];
